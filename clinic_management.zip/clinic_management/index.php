<?php

require "vendor/autoload.php";
require "init.php";

use Bramus\Router\Router;
use App\Controllers\PrescriptionsController;
use App\Controllers\AppointmentsController;
use App\Controllers\MedicalHistoryController;
use App\Controllers\NotificationsController;
use App\Controllers\RegisterController;

// Create a Router instance
$router = new Router();

// Database connection (pass it to the controllers)
global $conn;

// Route for the landing page
$router->get('/', '\App\Controllers\LandingController@index');

// Routes for login
$router->get('/login', '\App\Controllers\LoginController@showLoginPage'); // Show login page
$router->post('/login', '\App\Controllers\LoginController@authenticate'); // Authenticate user

// Routes for registration
$router->get('/register', function () {
    $controller = new RegisterController();
    $controller->showRegisterPage();
});
$router->post('/register', function () use ($conn) {
    $controller = new RegisterController($conn);
    $controller->register();
});

// Route for the dashboard
$router->get('/dashboard', '\App\Controllers\DashboardController@index'); // Show the dashboard

// Routes for appointments management
$router->get('/appointments', function () use ($conn) {
    $controller = new AppointmentsController($conn);
    $controller->index();
});
$router->post('/appointments/create', function () use ($conn) {
    $controller = new AppointmentsController($conn);
    $controller->create();
});
$router->post('/appointments/remove', function () use ($conn) {
    $controller = new AppointmentsController($conn);
    $controller->remove();
});

// Routes for medical history management
$router->get('/medical-history', function () use ($conn) {
    $controller = new MedicalHistoryController($conn);
    $controller->index();
});
$router->post('/medical-history/create', function () use ($conn) {
    $controller = new MedicalHistoryController($conn);
    $controller->create();
});

// Routes for prescriptions management
$router->get('/prescriptions', function () use ($conn) {
    $controller = new PrescriptionsController($conn);
    $controller->index();
});
$router->post('/prescriptions/create', function () use ($conn) {
    $controller = new PrescriptionsController($conn);
    $controller->create();
});

// Routes for notifications management
$router->get('/notifications', function () use ($conn) {
    $controller = new NotificationsController($conn);
    $controller->index();
});
$router->post('/notifications/mark-as-read/{id}', function ($id) use ($conn) {
    $controller = new NotificationsController($conn);
    $controller->markAsRead($id);
});

// Route for logout
$router->post('/logout', function () {
    session_start();
    session_destroy(); // Destroy the session
    header("Location: /login"); // Redirect to the login page
    exit;
});

// Routes for user profile management
$router->get('/profile', function () use ($conn) {
    $controller = new \App\Controllers\UserProfileController($conn);
    $controller->index();
});
$router->post('/profile/update', function () use ($conn) {
    $controller = new \App\Controllers\UserProfileController($conn);
    $controller->update();
});

// Routes for patient queue management
$router->get('/queue', function () use ($conn) {
    $controller = new \App\Controllers\PatientQueueController($conn);
    $controller->index();
});
$router->post('/queue/add', function () use ($conn) {
    $controller = new \App\Controllers\PatientQueueController($conn);
    $controller->add();
});

// Run the router
$router->run();
