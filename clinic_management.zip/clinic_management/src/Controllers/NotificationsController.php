<?php

namespace App\Controllers;

use Mustache_Engine;
use Mustache_Loader_FilesystemLoader;

class NotificationsController
{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function index()
    {
        session_start();

        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $student_id = $_SESSION['user_id'];

        try {
            // Fetch notifications for the logged-in user
            $stmt = $this->conn->prepare("SELECT * FROM notifications WHERE student_id = :student_id ORDER BY created_at DESC");
            $stmt->bindParam(':student_id', $student_id, \PDO::PARAM_INT);
            $stmt->execute();
            $notifications = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // Render the view with fetched notifications
            $mustache = new Mustache_Engine([
                'loader' => new Mustache_Loader_FilesystemLoader(__DIR__ . '/../../views'),
            ]);
            echo $mustache->render('notifications', ['notifications' => $notifications]);
        } catch (\PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    public function markAsRead($notification_id)
    {
        session_start();

        // Check if the user is logged in
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        try {
            // Mark a notification as read
            $stmt = $this->conn->prepare("UPDATE notifications SET read_status = 'Read' WHERE id = :id AND student_id = :student_id");
            $stmt->bindParam(':id', $notification_id, \PDO::PARAM_INT);
            $stmt->bindParam(':student_id', $_SESSION['user_id'], \PDO::PARAM_INT);
            if ($stmt->execute()) {
                header('Location: /notifications');
                exit;
            } else {
                echo "Error: Unable to update notification status.";
            }
        } catch (\PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
}
