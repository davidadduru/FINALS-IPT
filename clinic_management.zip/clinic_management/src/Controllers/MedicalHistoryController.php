<?php

namespace App\Controllers;

use Mustache_Engine;
use Mustache_Loader_FilesystemLoader;

class MedicalHistoryController
{
    public function index()
    {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit;
        }

        global $conn; // Use the database connection
        try {
            $stmt = $conn->query("SELECT * FROM medical_history ORDER BY visit_date DESC");
            $medicalHistory = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        } catch (\PDOException $e) {
            die('Database error: ' . $e->getMessage());
        }

        $mustache = new Mustache_Engine([
            'loader' => new Mustache_Loader_FilesystemLoader(__DIR__ . '/../../views'),
        ]);

        // Render the medical history page with data
        echo $mustache->render('medical-history', ['medicalHistory' => $medicalHistory]);
    }

    public function create()
    {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit;
        }

        global $conn; // Use the database connection

        $student_id = $_POST['student_id'] ?? '';
        $diagnosis = $_POST['diagnosis'] ?? '';
        $treatment = $_POST['treatment'] ?? '';
        $visit_date = $_POST['visit_date'] ?? '';

        if ($student_id && $diagnosis && $treatment && $visit_date) {
            try {
                $stmt = $conn->prepare("INSERT INTO medical_history (student_id, diagnosis, treatment, visit_date) VALUES (:student_id, :diagnosis, :treatment, :visit_date)");
                $stmt->bindValue(':student_id', $student_id, \PDO::PARAM_INT);
                $stmt->bindValue(':diagnosis', $diagnosis, \PDO::PARAM_STR);
                $stmt->bindValue(':treatment', $treatment, \PDO::PARAM_STR);
                $stmt->bindValue(':visit_date', $visit_date, \PDO::PARAM_STR);
                $stmt->execute();

                header("Location: /medical-history");
                exit;
            } catch (\PDOException $e) {
                die('Database error: ' . $e->getMessage());
            }
        } else {
            die('Error: Please provide all required fields.');
        }
    }
}
