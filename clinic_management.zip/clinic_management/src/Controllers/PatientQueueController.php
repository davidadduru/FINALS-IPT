<?php

namespace App\Controllers;

class PatientQueueController
{
    protected $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function index()
    {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit;
        }

        $student_id = $_SESSION['user_id'];

        // Fetch the queue data for the logged-in student
        $stmt = $this->conn->prepare("SELECT * FROM patient_queue WHERE student_id = :student_id");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->execute();
        $queue = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        // Render the queue management page
        $mustache = new \Mustache_Engine([
            'loader' => new \Mustache_Loader_FilesystemLoader(__DIR__ . '/../../views'),
        ]);

        echo $mustache->render('patient_queue', ['queue' => $queue]);
    }

    public function add()
    {
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: /login");
            exit;
        }

        $student_id = $_SESSION['user_id'];
        $status = "Waiting";

        // Add new entry to the queue
        $stmt = $this->conn->prepare("INSERT INTO patient_queue (student_id, status, created_at) VALUES (:student_id, :status, NOW())");
        $stmt->bindParam(':student_id', $student_id);
        $stmt->bindParam(':status', $status);

        if ($stmt->execute()) {
            header("Location: /queue");
        } else {
            echo "Error: Could not add to queue.";
        }
    }
}
